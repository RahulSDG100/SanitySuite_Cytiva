var searchData=
[
  ['logmanager_299',['LogManager',['../classcom_1_1common_1_1framework_1_1log_1_1_log_manager.html',1,'com::common::framework::log']]]
];
