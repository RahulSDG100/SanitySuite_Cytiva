var searchData=
[
  ['xmlreader_2ejava_395',['XmlReader.java',['../_xml_reader_8java.html',1,'']]]
];
